# Activity 3: gittin' around

### July 3, 2025

### Skiers (John Chin, Ian Olson, Bowen Huang)

![git visual demo](./assets/Screenshot%202025-07-03%20at%2010.56.44 AM.png)
